"""
Vetran SDK — Data Models
"""

from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class Agent:
    """Represents a registered agent in the Vetran registry."""
    agent_id:           str
    name:               str
    owner:              str
    token:              str
    status:             str
    badge:              str
    vetran_score:       int
    capabilities:       List[str]
    verification_count: int
    delegation_count:   int
    registered_at:      str
    last_verified_at:   Optional[str] = None
    model:              Optional[str] = None
    description:        Optional[str] = None

    @property
    def is_active(self) -> bool:
        return self.status == "ACTIVE"

    @property
    def is_revoked(self) -> bool:
        return self.status == "REVOKED"

    @property
    def is_elite(self) -> bool:
        return self.badge == "ELITE"

    def __repr__(self):
        return (
            f"Agent(id={self.agent_id!r}, name={self.name!r}, "
            f"badge={self.badge!r}, status={self.status!r})"
        )

    @classmethod
    def from_dict(cls, data: dict, token: str = "") -> "Agent":
        agent_data = data.get("agent", data)
        return cls(
            agent_id=           agent_data.get("agentId", ""),
            name=               agent_data.get("name", ""),
            owner=              agent_data.get("owner", ""),
            token=              data.get("token", token),
            status=             agent_data.get("status", "ACTIVE"),
            badge=              agent_data.get("badge", "ROOKIE"),
            vetran_score=       agent_data.get("vetranScore", 100),
            capabilities=       agent_data.get("capabilities", []),
            verification_count= agent_data.get("verificationCount", 0),
            delegation_count=   agent_data.get("delegationCount", 0),
            registered_at=      agent_data.get("registeredAt", ""),
            last_verified_at=   agent_data.get("lastVerifiedAt"),
            model=              agent_data.get("model"),
            description=        agent_data.get("description"),
        )


@dataclass
class CapabilityCheck:
    """Result of a capability check during verification."""
    passed:  bool
    missing: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "CapabilityCheck":
        return cls(
            passed=  data.get("passed", True),
            missing= data.get("missing", []),
        )


@dataclass
class VerifyResult:
    """Result of a /verify call."""
    verified:          bool
    cleared:           bool
    agent:             Optional[Agent]
    capability_check:  CapabilityCheck
    verified_at:       str
    error:             Optional[str] = None
    message:           Optional[str] = None

    @property
    def blocked(self) -> bool:
        return not self.cleared

    def __repr__(self):
        status = "CLEARED" if self.cleared else "BLOCKED"
        return f"VerifyResult({status}, agent={self.agent.agent_id if self.agent else None!r})"

    @classmethod
    def from_dict(cls, data: dict) -> "VerifyResult":
        agent = None
        if data.get("agent"):
            agent = Agent.from_dict({"agent": data["agent"]})

        cap_check = CapabilityCheck.from_dict(
            data.get("capabilityCheck", {"passed": True, "missing": []})
        )

        return cls(
            verified=         data.get("verified", False),
            cleared=          data.get("clearedToExecute", False),
            agent=            agent,
            capability_check= cap_check,
            verified_at=      data.get("verifiedAt", ""),
            error=            data.get("error"),
            message=          data.get("message"),
        )


@dataclass
class DelegationResult:
    """Result of a /delegate call."""
    delegation_id:       str
    delegation_token:    str
    chain:               List[str]
    scoped_capabilities: List[str]
    expires_in:          str
    parent_name:         Optional[str] = None
    child_name:          Optional[str] = None

    def __repr__(self):
        chain_str = " → ".join(self.chain)
        return f"DelegationResult(id={self.delegation_id!r}, chain={chain_str!r})"

    @classmethod
    def from_dict(cls, data: dict) -> "DelegationResult":
        return cls(
            delegation_id=       data.get("delegationId", ""),
            delegation_token=    data.get("delegationToken", ""),
            chain=               data.get("chain", []),
            scoped_capabilities= data.get("scopedCapabilities", []),
            expires_in=          data.get("expiresIn", "24h"),
        )


@dataclass
class StatusResult:
    """Current standing of an agent in the Vetran registry."""
    agent_id:           str
    name:               str
    owner:              str
    status:             str
    badge:              str
    vetran_score:       int
    capabilities:       List[str]
    verification_count: int
    delegation_count:   int
    registered_at:      str
    last_verified_at:   Optional[str] = None

    @property
    def is_active(self) -> bool:
        return self.status == "ACTIVE"

    def __repr__(self):
        return (
            f"StatusResult(id={self.agent_id!r}, badge={self.badge!r}, "
            f"verifications={self.verification_count})"
        )

    @classmethod
    def from_dict(cls, data: dict) -> "StatusResult":
        return cls(
            agent_id=           data.get("agentId", ""),
            name=               data.get("name", ""),
            owner=              data.get("owner", ""),
            status=             data.get("status", ""),
            badge=              data.get("badge", "ROOKIE"),
            vetran_score=       data.get("vetranScore", 100),
            capabilities=       data.get("capabilities", []),
            verification_count= data.get("verificationCount", 0),
            delegation_count=   data.get("delegationCount", 0),
            registered_at=      data.get("registeredAt", ""),
            last_verified_at=   data.get("lastVerifiedAt"),
        )
