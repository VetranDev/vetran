"""
Vetran SDK — HTTP Client
"""

import os
import requests
from typing import List, Optional

from .models import Agent, VerifyResult, DelegationResult, StatusResult
from .exceptions import (
    VetranError, AgentNotFoundError, AgentRevokedError,
    InvalidTokenError, MissingFieldsError, VetranConnectionError,
)

DEFAULT_API_URL = "https://vetran.dev"


class VetranClient:
    """
    Vetran HTTP client.

    Usage:
        client = VetranClient(api_url="https://vetran.dev")
        agent = client.register(name="MyAgent", owner="acme")
    """

    def __init__(
        self,
        api_url: str  = None,
        api_key: str  = None,
        timeout: int  = 10,
    ):
        self.api_url = (
            api_url
            or os.environ.get("VETRAN_API_URL")
            or DEFAULT_API_URL
        ).rstrip("/")

        self.api_key = api_key or os.environ.get("VETRAN_API_KEY")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "User-Agent":   "vetran-python/1.0.0",
        })
        if self.api_key:
            self.session.headers.update({"X-Vetran-Key": self.api_key})

    # ── Internal ────────────────────────────────────────────────────────────

    def _post(self, path: str, data: dict) -> dict:
        try:
            resp = self.session.post(
                f"{self.api_url}{path}",
                json=data,
                timeout=self.timeout,
            )
            return self._handle(resp)
        except requests.exceptions.ConnectionError:
            raise VetranConnectionError(
                f"Cannot reach Vetran registry at {self.api_url}. "
                "Is the server running?"
            )
        except requests.exceptions.Timeout:
            raise VetranConnectionError(
                f"Request to Vetran timed out after {self.timeout}s"
            )

    def _get(self, path: str) -> dict:
        try:
            resp = self.session.get(
                f"{self.api_url}{path}",
                timeout=self.timeout,
            )
            return self._handle(resp)
        except requests.exceptions.ConnectionError:
            raise VetranConnectionError(
                f"Cannot reach Vetran registry at {self.api_url}"
            )
        except requests.exceptions.Timeout:
            raise VetranConnectionError(
                f"Request to Vetran timed out after {self.timeout}s"
            )

    def _handle(self, resp: requests.Response) -> dict:
        try:
            data = resp.json()
        except Exception:
            raise VetranError(f"Invalid JSON response (status {resp.status_code})")

        if resp.status_code == 400:
            raise MissingFieldsError(data.get("message", "Missing required fields"))

        if resp.status_code == 401:
            raise InvalidTokenError(data.get("message", "Token is invalid or expired"))

        if resp.status_code == 403:
            error = data.get("error", "")
            if "REVOKED" in error:
                raise AgentRevokedError(
                    data.get("message", "Agent has been revoked"),
                    revoked_at=data.get("revokedAt"),
                )
            raise VetranError(data.get("message", "Forbidden"))

        if resp.status_code == 404:
            raise AgentNotFoundError(data.get("message", "Agent not found"))

        if resp.status_code >= 500:
            raise VetranError(f"Vetran server error: {data.get('message', resp.text)}")

        return data

    # ── Public API ───────────────────────────────────────────────────────────

    def register(
        self,
        name: str,
        owner: str,
        capabilities: List[str] = None,
        model: str = None,
        description: str = None,
    ) -> Agent:
        """Register a new agent and receive a signed identity token."""
        payload = {"name": name, "owner": owner}
        if capabilities:  payload["capabilities"]  = capabilities
        if model:         payload["model"]          = model
        if description:   payload["description"]    = description

        data = self._post("/register", payload)
        return Agent.from_dict(data)

    def verify(
        self,
        token: str,
        requested_capabilities: List[str] = None,
    ) -> VerifyResult:
        """Verify an agent's token and check capability clearance."""
        payload = {"token": token}
        if requested_capabilities:
            payload["requestedCapabilities"] = requested_capabilities

        data = self._post("/verify", payload)
        return VerifyResult.from_dict(data)

    def delegate(
        self,
        parent_token: str,
        child_agent_id: str,
        scoped_capabilities: List[str] = None,
        expires_in: str = "24h",
    ) -> DelegationResult:
        """Issue a scoped trust delegation from parent to child agent."""
        payload = {
            "parentToken":  parent_token,
            "childAgentId": child_agent_id,
            "expiresIn":    expires_in,
        }
        if scoped_capabilities:
            payload["scopedCapabilities"] = scoped_capabilities

        data = self._post("/delegate", payload)
        return DelegationResult.from_dict(data)

    def status(self, agent_id: str) -> StatusResult:
        """Get the current standing of an agent."""
        data = self._get(f"/status/{agent_id}")
        return StatusResult.from_dict(data)

    def revoke(self, agent_id: str, reason: str = None) -> dict:
        """Immediately revoke an agent."""
        payload = {}
        if reason:
            payload["reason"] = reason
        return self._post(f"/revoke/{agent_id}", payload)

    def ping(self) -> bool:
        """Check if the Vetran registry is reachable."""
        try:
            data = self._get("/")
            return data.get("status") == "operational"
        except VetranConnectionError:
            return False
