"""
Vetran SDK — Exceptions
"""


class VetranError(Exception):
    """Base exception for all Vetran errors."""
    pass


class VetranConnectionError(VetranError):
    """Cannot reach the Vetran registry."""
    pass


class AgentNotFoundError(VetranError):
    """Agent does not exist in the Vetran registry."""
    pass


class AgentRevokedError(VetranError):
    """Agent has been revoked and cannot execute."""
    def __init__(self, message: str, revoked_at: str = None):
        super().__init__(message)
        self.revoked_at = revoked_at


class InvalidTokenError(VetranError):
    """JWT token is invalid, tampered, or expired."""
    pass


class MissingFieldsError(VetranError):
    """Required fields are missing from the request."""
    pass
